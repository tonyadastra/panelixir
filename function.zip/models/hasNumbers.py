def hasNumbers(string):
    return any(char.isdigit() for char in string)
